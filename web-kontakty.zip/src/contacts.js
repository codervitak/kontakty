const contacts = [
  {
    id: 1,
    name: "Elon Musk",
    img: "https://picsum.photos/seed/ffgtff6200/200",
    email: "elon.musk@volny.cz",
    tel: "+420 777 123 456"
  },
  {
    id: 2,
    name: "Bill Gates",
    img: "https://picsum.photos/seed/21s48gak/200",
    email: "bill.gates@atlas.cz",
    tel: "+420 602 123 000"
  },
  {
    id: 3,
    name: "Mark Zuckerberg",
    img: "https://picsum.photos/seed/5zgd622/200",
    email: "marek@centrum.cz",
    tel: "+420 720 000 000"
  },
  {
    id: 4,
    name: "Milan Kvajsar",
    img: "https://picsum.photos/seed/54gth455585/200",
    email: "kvaky@gyarab.cz",
    tel: "+420 987 654 321"
  },
  {
    id: 5,
    name: "Bageta Debrecínská",
    img: "https://picsum.photos/seed/54mamradbaget/200",
    email: "debrecinka@bagety.eu",
    tel: "+420 332 732 462"
  }
];

export default contacts;
